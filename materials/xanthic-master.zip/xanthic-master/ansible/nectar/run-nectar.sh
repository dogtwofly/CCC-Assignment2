#! /bin/bash

. ./unimelb-comp90024-group-18-openrc.sh; ansible-playbook --ask-become-pass nectar.yaml